//
//  QuickViewDescriptionCustomCell.m
//  OnlineTimeSheet
//
//  Created by dave on 2/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
/*
#import "QuickViewDescriptionCustomCell.h"

@implementation QuickViewDescriptionCustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
*/
//
//  MandateCustomCell.m
//  EITOnlineTimeSheet
//
//  Created by dave on 5/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TimePerDayCustomCell.h"
#import "TimeSheetViewController.h"
//#import "ApplyPersonalDetailsViewController.h"

@implementation TimePerDayCustomCell

@synthesize lblTime;
@synthesize lblText;
@synthesize cmdEdit;
@synthesize viewForBackground;
//@synthesize applyPersonalDetailsView;
//@synthesize timePerDayView;
@synthesize timesheetView;
@synthesize nRowIdx;
//@synthesize membershipView;
@synthesize sDate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (IBAction) loadTimeSheetView:(id)sender{
    /*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Test MSG" message:@"Do you really want to do this?" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:@"Yes", nil];
	[alert show];
	[alert release];*/
    //[timePerDayView reloadTimesheet:sDate];
    //[timePerDayView cancel:nil];
}

- (IBAction) editTimesheetEntry:(id)sender{
	/*ApplyPersonalDetailsViewController *controller = [[ApplyPersonalDetailsViewController alloc] initWithNibName:@"ApplyPersonalDetailsView" bundle:nil];
	
	MembershipMandateEntry *mme = [membershipView.arrMembershipMandateEntries objectAtIndex:nRowIdx];
	//TimeSheetEntry *tse = [timesheetView.arrTimeSheetEntries objectAtIndex:nRowIdx];
	//controller.tsView= timesheetView;
	[controller loadMembershipMandatetEntry:mme];
	//[self setAddTimesheetView:controller];
	[self setApplyPersonalDetailsView:controller];
	[controller release];
	//[self.contentView.superview.superview.superview addSubview:[addTimesheetView view]];
	[self.contentView.superview.superview.superview addSubview:[applyPersonalDetailsView view]];
	*/
	//TimeSheetViewController *tsView = self.contentView.superview.superview.superview;
	//[tsView showTimesheetEntry];
}



@end
