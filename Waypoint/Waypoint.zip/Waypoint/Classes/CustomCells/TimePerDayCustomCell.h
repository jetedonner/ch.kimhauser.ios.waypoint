//
//  QuickViewDescriptionCustomCell.h
//  OnlineTimeSheet
//
//  Created by dave on 2/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
/*
#import <UIKit/UIKit.h>

@interface QuickViewDescriptionCustomCell : UITableViewCell

@end
*/
#import <UIKit/UIKit.h>
#import "TimeSheetViewController.h"
//#import "ApplyPersonalDetailsViewController.h"
//#import "ApplyForMembershipViewController.h"
//#import "TimePerDayCustomCell.h"

@interface TimePerDayCustomCell : UITableViewCell {
	IBOutlet UILabel *lblTime;
	IBOutlet UILabel *lblText;
	IBOutlet UIButton *cmdEdit;
	
	IBOutlet UIView *viewForBackground;
	//ApplyPersonalDetailsViewController *applyPersonalDetailsView;
	//TimeSheetViewController *timesheetView;
	//ApplyForMembershipViewController *membershipView;
    //TimePerDayViewController *timePerDayView;
    
    NSString *sDate;
    
	int nRowIdx;
}
//@property (nonatomic, retain) ApplyForMembershipViewController *membershipView;
@property (nonatomic, retain) TimeSheetViewController *timesheetView;

@property (nonatomic, retain) UILabel *lblTime;
@property (nonatomic, retain) UILabel *lblText;
@property (nonatomic, retain) UIButton *cmdEdit;
@property (nonatomic, retain) UIView *viewForBackground;
//@property (nonatomic, retain) ApplyPersonalDetailsViewController *applyPersonalDetailsView;
//@property (nonatomic, retain) TimePerDayViewController *timePerDayView;
@property (nonatomic, retain) NSString *sDate;
@property (nonatomic) int nRowIdx;

- (IBAction) loadTimeSheetView:(id)sender;
- (IBAction) editTimesheetEntry:(id)sender;

@end