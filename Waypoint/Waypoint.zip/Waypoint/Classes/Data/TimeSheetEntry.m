//
//  TimeSheetEntry.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TimeSheetEntry.h"


@implementation TimeSheetEntry

@synthesize tHoursWorked;
@synthesize dStartTime;
@synthesize dEndTime;
@synthesize sDescription;
@synthesize nClientID;
@synthesize sClient;
@synthesize nProjectID;
@synthesize sProject;
@synthesize nWorkcodeID;
@synthesize sWorkcode;
@synthesize sWorkdate;
@synthesize nID;
@end
