//
//  MinMaxDateEntry.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MinMaxDateEntry.h"


@implementation MinMaxDateEntry
@synthesize sDate;
@synthesize sMin;
@synthesize sMax;
@synthesize nMinHour;
@synthesize nMinMinute;
@synthesize nMinSecond;
@synthesize nMaxHour;
@synthesize nMaxMinute;
@synthesize nMaxSecond;
@synthesize sWorkTime;
@end
