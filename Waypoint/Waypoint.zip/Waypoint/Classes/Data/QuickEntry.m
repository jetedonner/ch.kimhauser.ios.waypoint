//
//  QuickEntry.m
//  OnlineTimeSheet
//
//  Created by dave on 2/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "QuickEntry.h"

@implementation QuickEntry

@synthesize startTime;
@synthesize endTime;
@synthesize qeType;

@end
