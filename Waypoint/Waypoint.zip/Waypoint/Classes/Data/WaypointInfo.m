//
//  WaypointInfo.m
//  Waypoint
//
//  Created by dave on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "WaypointInfo.h"


@implementation WaypointInfo

@synthesize nWaypointId;
@synthesize nClientId;
@synthesize nProjectId;
@synthesize nWorkcodeId;

@synthesize dLat;
@synthesize dLng;
@synthesize dRad;
@synthesize sName;

@synthesize sClient;
@synthesize sProject;
@synthesize sWorkcode;

@end
