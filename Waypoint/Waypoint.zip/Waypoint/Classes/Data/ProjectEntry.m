//
//  ProjectEntry.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ProjectEntry.h"


@implementation ProjectEntry

@synthesize nProjectID;
@synthesize sProjectName;

@end
