//
//  WorkcodeEntry.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WorkcodeEntry.h"


@implementation WorkcodeEntry

@synthesize nWorkcodeID;
@synthesize sWorkcode;

@end
