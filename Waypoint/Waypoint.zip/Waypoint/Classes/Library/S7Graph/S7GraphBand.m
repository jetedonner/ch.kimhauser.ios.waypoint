//
//  S7GraphBand.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "S7GraphBand.h"


@implementation S7GraphBand
@synthesize nStart;
@synthesize nStop;
@synthesize nStart2;
@synthesize nStop2;
@synthesize bandColor;
@end
