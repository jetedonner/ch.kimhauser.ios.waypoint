//
//  WorkcodeEntry.m
//  EITOnlineTimeSheet
//
//  Created by dave on 4/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LoginAnswere.h"


@implementation LoginAnswere

//@synthesize nWorkcodeID;
//@synthesize sWorkcode;
@synthesize nResult;
@synthesize nUserID;
@synthesize sUsername;
@synthesize nMandateID;
@synthesize sSessionID;

@end
