//
//  MembershipMainViewController.h
//  Waypoint
//
//  Created by Kim David Hauser on 02.07.12.
//  Copyright (c) 2012 DaVe inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MembershipMainViewController : UIViewController

@end
